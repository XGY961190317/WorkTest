package com.example.expandablelistviewdemo.utils;

public class ParseUtils {
    public void parseImagData(){//解析图片

    }
    public void parseArticleData(){//解析文章

    }
}
