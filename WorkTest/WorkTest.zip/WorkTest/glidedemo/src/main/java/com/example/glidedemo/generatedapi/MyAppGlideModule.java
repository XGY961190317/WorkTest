package com.example.glidedemo.generatedapi;


import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * 生成GlideApp对象，用这个生成GlideApp对象对象替换Glide对象
 */
@GlideModule
public class MyAppGlideModule extends AppGlideModule {
}
