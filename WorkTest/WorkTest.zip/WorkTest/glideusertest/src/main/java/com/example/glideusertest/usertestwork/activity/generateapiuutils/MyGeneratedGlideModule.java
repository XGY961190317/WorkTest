package com.example.glideusertest.usertestwork.activity.generateapiuutils;


import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class MyGeneratedGlideModule extends AppGlideModule {
}
