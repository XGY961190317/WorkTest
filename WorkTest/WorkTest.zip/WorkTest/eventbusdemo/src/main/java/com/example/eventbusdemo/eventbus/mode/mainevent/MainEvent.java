package com.example.eventbusdemo.eventbus.mode.mainevent;

public class MainEvent {
    public String threadInfo;

    public MainEvent(String threadInfo) {
        this.threadInfo = threadInfo;
    }
}
