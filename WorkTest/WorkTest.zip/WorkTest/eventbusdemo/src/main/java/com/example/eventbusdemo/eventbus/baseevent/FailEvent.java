package com.example.eventbusdemo.eventbus.baseevent;

public class FailEvent {
}
