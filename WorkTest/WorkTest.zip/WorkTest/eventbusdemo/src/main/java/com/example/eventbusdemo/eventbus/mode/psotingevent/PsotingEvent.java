package com.example.eventbusdemo.eventbus.mode.psotingevent;

public class PsotingEvent {
    public String threadInfo;

    public PsotingEvent(String threadInfo) {
        this.threadInfo = threadInfo;
    }
}
