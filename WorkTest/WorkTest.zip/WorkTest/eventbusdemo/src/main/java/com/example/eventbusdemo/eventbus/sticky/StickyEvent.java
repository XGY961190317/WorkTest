package com.example.eventbusdemo.eventbus.sticky;

public class StickyEvent {
    public String subscriber_msg;

    public StickyEvent(String subscriber_msg) {
        this.subscriber_msg = subscriber_msg;
    }
}
